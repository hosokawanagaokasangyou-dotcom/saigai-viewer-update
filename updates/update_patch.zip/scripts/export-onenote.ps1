﻿<#
.SYNOPSIS
  OneNote デスクトップ COM からページ本文と添付を JSON / ファイルへ書き出す。
#>
param(
    [Parameter(Mandatory = $true)][string]$OneNotePath,
    [Parameter(Mandatory = $true)][string]$OutputJson,
    [int]$MinPages = 1
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

function Write-ExportProgress([string]$line) {
    Write-Output $line
    try { [Console]::Out.Flush() } catch { }
}

function Convert-HtmlToPlain([string]$html) {
    if ([string]::IsNullOrWhiteSpace($html)) { return "" }
    $s = $html
    $s = [regex]::Replace($s, '(?i)</?\s*(br|p|div|tr|li|h[1-6])\b[^>]*>', "`n")
    $s = [regex]::Replace($s, '(?s)<[^>]+>', '')
    $s = $s.Replace('&nbsp;', ' ').Replace('&#160;', ' ')
    $s = $s.Replace('&amp;', '&').Replace('&lt;', '<').Replace('&gt;', '>').Replace('&quot;', '"')
    $s = [regex]::Replace($s, "`n{3,}", "`n`n")
    return $s.Trim()
}

function Get-PlainTextFromPageXml([string]$xml) {
    if ([string]::IsNullOrWhiteSpace($xml)) { return "" }
    try {
        $doc = New-Object System.Xml.XmlDocument
        $doc.PreserveWhitespace = $true
        $doc.LoadXml($xml)
        $ns = New-Object System.Xml.XmlNamespaceManager($doc.NameTable)
        $ns.AddNamespace("one", "http://schemas.microsoft.com/office/onenote/2013/onenote")
        $texts = $doc.SelectNodes("//one:T", $ns)
        $buf = New-Object System.Text.StringBuilder
        foreach ($t in $texts) {
            $inner = Convert-HtmlToPlain $t.InnerText
            if ($inner) { [void]$buf.AppendLine($inner) }
        }
        return $buf.ToString().Trim()
    } catch {
        return Convert-HtmlToPlain $xml
    }
}

function Get-SafeName([string]$name) {
    # 添付の表示名。日本語や空白は残し、Windows でファイル名に使えない文字だけ _ にする。
    # ページ JSON の ID 用（ASCII 限定）とは別。
    if ([string]::IsNullOrWhiteSpace($name)) { return "file" }
    $leaf = $name.Trim() -replace '[\\/]+$', ''
    $slash = [Math]::Max($leaf.LastIndexOf('\'), $leaf.LastIndexOf('/'))
    if ($slash -ge 0) { $leaf = $leaf.Substring($slash + 1) }
    if ([string]::IsNullOrWhiteSpace($leaf)) { $leaf = "file" }
    # GetFileName は < > などを含むと例外になるため、先に禁止文字を落とす
    $s = [regex]::Replace($leaf, '[<>:"/\\|?*\x00-\x1F]', '_')
    $s = $s.TrimEnd(' ', '.')
    if ([string]::IsNullOrWhiteSpace($s) -or $s -eq '.' -or $s -eq '..') { $s = 'file' }
    $reserved = @('CON','PRN','AUX','NUL','COM1','COM2','COM3','COM4','LPT1','LPT2','LPT3')
    $base = $s
    $dot = $s.LastIndexOf('.')
    if ($dot -gt 0) { $base = $s.Substring(0, $dot) }
    if ($reserved -contains $base.ToUpperInvariant()) { $s = '_' + $s }
    if ($s.Length -gt 120) {
        $ext = ''
        $dot2 = $s.LastIndexOf('.')
        if ($dot2 -gt 0 -and ($s.Length - $dot2) -le 16) { $ext = $s.Substring($dot2) }
        $maxBase = 120 - $ext.Length
        if ($maxBase -lt 1) {
            $s = $s.Substring(0, 120)
        } else {
            $b = if ($ext) { $s.Substring(0, $s.Length - $ext.Length) } else { $s }
            if ($b.Length -gt $maxBase) { $b = $b.Substring(0, $maxBase).TrimEnd(' ', '.') }
            if ([string]::IsNullOrWhiteSpace($b)) { $b = 'file' }
            $s = $b + $ext
        }
    }
    return $s
}

function Get-PageAttachDirName([string]$pageId) {
    # Java PageAttachDir.shortName と一致させる
    if ([string]::IsNullOrWhiteSpace($pageId)) { return "p0" }
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $bytes = $sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($pageId))
    $hex = -join ($bytes[0..7] | ForEach-Object { '{0:x2}' -f $_ })
    return "p$hex"
}

function ConvertTo-PageJson($items) {
    $arr = @($items)
    if ($arr.Count -eq 0) { return "[]" }
    $json = ConvertTo-Json -InputObject $arr -Depth 6
    if ($json -is [System.Array]) { $json = ($json -join "`n") }
    $text = [string]$json
    if (-not $text.TrimStart().StartsWith("[")) {
        return "[" + $text + "]"
    }
    return $text
}

function Test-PageContentReadable($onenote, [string]$pageId) {
    if ([string]::IsNullOrWhiteSpace($pageId)) { return $false }
    $pageXml = ""
    try {
        $onenote.GetPageContent($pageId, [ref]$pageXml, 7) | Out-Null
    } catch {
        return $false
    }
    if ([string]::IsNullOrWhiteSpace($pageXml)) { return $false }
    return $pageXml -match '<[^>]*:?Page[\s>]'
}

function Get-HierarchyPages($onenote, [string]$notebookId) {
    $hierarchy = ""
    $onenote.GetHierarchy($notebookId, 4, [ref]$hierarchy) | Out-Null
    $hdoc = New-Object System.Xml.XmlDocument
    $hdoc.LoadXml($hierarchy)
    $uri = $hdoc.DocumentElement.NamespaceURI
    if ([string]::IsNullOrWhiteSpace($uri)) {
        $uri = "http://schemas.microsoft.com/office/onenote/2013/onenote"
    }
    $ns = New-Object System.Xml.XmlNamespaceManager($hdoc.NameTable)
    $ns.AddNamespace("one", $uri)
    $matched = New-Object System.Collections.Generic.List[System.Xml.XmlNode]
    foreach ($node in $hdoc.SelectNodes("//one:Page", $ns)) { $matched.Add($node) }
    $usedLocal = $false
    if ($matched.Count -eq 0) {
        foreach ($node in $hdoc.SelectNodes("//*[local-name()='Page']")) { $matched.Add($node) }
        if ($matched.Count -gt 0) { $usedLocal = $true }
    }
    $sections = 0
    foreach ($node in $hdoc.SelectNodes("//*[local-name()='Section']")) { $sections++ }
    return @{
        Document     = $hdoc
        Namespace    = $ns
        Pages        = $matched
        Sections     = $sections
        Xmlns        = $uri
        UsedLocalName = $usedLocal
        Chars        = $hierarchy.Length
    }
}

function Test-IsOneNoteCachePath([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path)) { return $false }
    try {
        $full = [System.IO.Path]::GetFullPath($path)
    } catch { return $false }
    $n = $full.ToLowerInvariant().Replace('/', '\')
    return ($n -like '*\microsoft\onenote\*\cache\*') -or ($n -like '*\microsoft\onenote\*\cache')
}

if (-not (Test-Path -LiteralPath $OneNotePath)) {
    throw "OneNote ファイルが見つかりません: $OneNotePath"
}

Write-ExportProgress "status=OneNote を起動しています"
$onenote = $null
try {
    $onenote = New-Object -ComObject OneNote.Application
} catch {
    throw "OneNote デスクトップ版の COM 起動に失敗しました。OneNote がインストールされているか確認してください。 $_"
}

Write-ExportProgress "status=ノートブックを開いています"
# ノートを開き、そのノートブック配下だけを対象にする（全ノート混入を防ぐ）
$notebookId = ""
try {
    $onenote.OpenHierarchy($OneNotePath, "", [ref]$notebookId, 0) | Out-Null
} catch {
    try {
        $onenote.NavigateTo($OneNotePath) | Out-Null
    } catch { }
}

if ([string]::IsNullOrWhiteSpace($notebookId)) {
    # OpenHierarchy が ID を返さない場合、パス一致の Notebook を探す
    $allHier = ""
    $onenote.GetHierarchy("", 4, [ref]$allHier) | Out-Null
    $allDoc = New-Object System.Xml.XmlDocument
    $allDoc.LoadXml($allHier)
    $allNs = New-Object System.Xml.XmlNamespaceManager($allDoc.NameTable)
    $allNs.AddNamespace("one", "http://schemas.microsoft.com/office/onenote/2013/onenote")
    $targetLeaf = [System.IO.Path]::GetFileNameWithoutExtension($OneNotePath)
    foreach ($nb in $allDoc.SelectNodes("//one:Notebook", $allNs)) {
        $nbPath = $nb.GetAttribute("path")
        $nbName = $nb.GetAttribute("name")
        if (($nbPath -and ($nbPath -ieq $OneNotePath -or $nbPath -like ("*" + $targetLeaf + "*"))) `
            -or ($nbName -and $nbName -like ("*" + $targetLeaf + "*"))) {
            $notebookId = $nb.GetAttribute("ID")
            break
        }
    }
}

if ([string]::IsNullOrWhiteSpace($notebookId)) {
    throw "対象ノートブックを特定できませんでした: $OneNotePath"
}

Write-ExportProgress ("diag=notebook=" + $OneNotePath)
Write-ExportProgress ("diag=notebookId=" + $notebookId)

# COM 起動後、件数が必要数で安定し、見本ページの本文 XML が取れるまで最大 90 秒待つ。
if ($MinPages -lt 1) { $MinPages = 1 }
$deadline = (Get-Date).AddSeconds(90)
$previousCount = -1
$snap = $null
$ready = $false
$readable = $false
do {
    $snap = Get-HierarchyPages $onenote $notebookId
    $count = $snap.Pages.Count
    $readable = $false
    if ($count -gt 0) {
        $sampleId = $snap.Pages[0].GetAttribute("ID")
        $readable = Test-PageContentReadable $onenote $sampleId
    }
    Write-ExportProgress ("diag=pageNodes=" + $count)
    Write-ExportProgress ("diag=minPages=" + $MinPages)
    Write-ExportProgress ("diag=sections=" + $snap.Sections)
    Write-ExportProgress ("diag=xmlns=" + $snap.Xmlns)
    Write-ExportProgress ("diag=hierarchyChars=" + $snap.Chars)
    Write-ExportProgress ("diag=contentReadable=" + $readable)
    if ($snap.UsedLocalName) { Write-ExportProgress "diag=pageMatch=local-name" }
    $readableLabel = if ($readable) { "本文あり" } else { "本文なし" }
    Write-ExportProgress ("status=OneNote の読み込みを確認しています（" + $count + " 件、" + $readableLabel + "）")
    # 必要件数未満は、別ノートIDの複製として保存すると重複除外が要約のページを落とす。書き出さない。
    if ($count -ge $MinPages -and $count -eq $previousCount -and $readable) {
        $ready = $true
        break
    }
    $previousCount = $count
    if ((Get-Date) -ge $deadline) { break }
    Start-Sleep -Seconds 3
} while ($true)
Write-ExportProgress ("diag=ready=" + $ready.ToString().ToLower())

$hdoc = $snap.Document
$ns = $snap.Namespace

$outDir = Split-Path -Parent $OutputJson
$attachRoot = Join-Path $outDir "attachments"
if (-not (Test-Path -LiteralPath $attachRoot)) {
    New-Item -ItemType Directory -Force -Path $attachRoot | Out-Null
}

$pages = @()
if (-not $ready) {
    Write-ExportProgress "status=OneNote の本文がまだ読めないため、書き出しを見送ります"
    $pageNodes = @()
} else {
    $pageNodes = $snap.Pages
}
$total = @($pageNodes).Count
Write-ExportProgress ("diag=pageNodes=" + $total)
Write-ExportProgress ("status=ページを書き出します（" + $total + " 件）")
$i = 0
foreach ($page in $pageNodes) {
    $id = $page.GetAttribute("ID")
    $name = $page.GetAttribute("name")
    $i++
    Write-ExportProgress ("exporting=" + $i + "/" + $total + " " + $name)
    $lm = $page.GetAttribute("lastModifiedTime")
    if (-not $lm) { $lm = [DateTime]::UtcNow.ToString("o") }
    $pageXml = ""
    try {
        $onenote.GetPageContent($id, [ref]$pageXml, 7) | Out-Null
    } catch {
        $pageXml = ""
    }
    $body = Get-PlainTextFromPageXml $pageXml
    $attachments = @()
    $pageSafe = Get-PageAttachDirName $id
    $pageAttachDir = Join-Path $attachRoot $pageSafe
    try {
        $pdoc = New-Object System.Xml.XmlDocument
        if ($pageXml) {
            $pdoc.LoadXml($pageXml)
            $pns = New-Object System.Xml.XmlNamespaceManager($pdoc.NameTable)
            $pns.AddNamespace("one", "http://schemas.microsoft.com/office/onenote/2013/onenote")
            $idx = 0
            foreach ($ins in $pdoc.SelectNodes("//one:InsertedFile", $pns)) {
                $idx++
                $cache = $ins.GetAttribute("pathCache")
                $preferred = $ins.GetAttribute("preferredName")
                if (-not $preferred) { $preferred = "attachment-$idx.bin" }
                $fileName = Get-SafeName $preferred
                if (-not $cache -or -not (Test-Path -LiteralPath $cache)) {
                    # 実ファイルが無い場合はゴースト記録しない
                    continue
                }
                if (-not (Test-IsOneNoteCachePath $cache)) {
                    # OneNote cache 以外はコピーしない
                    continue
                }
                if (-not (Test-Path -LiteralPath $pageAttachDir)) {
                    New-Item -ItemType Directory -Force -Path $pageAttachDir | Out-Null
                }
                $dest = Join-Path $pageAttachDir $fileName
                # 同名が複数ある場合は連番
                if (Test-Path -LiteralPath $dest) {
                    $base = [System.IO.Path]::GetFileNameWithoutExtension($fileName)
                    $ext = [System.IO.Path]::GetExtension($fileName)
                    $dest = Join-Path $pageAttachDir ($base + "-" + $idx + $ext)
                    $fileName = [System.IO.Path]::GetFileName($dest)
                }
                Copy-Item -LiteralPath $cache -Destination $dest -Force
                try { (Get-Item -LiteralPath $dest).IsReadOnly = $false } catch { }
                $attachments += ($pageSafe + "/" + $fileName)
            }
        }
    } catch { }

    $iso = $lm
    try {
        $iso = ([DateTime]$lm).ToUniversalTime().ToString("o")
    } catch { }

    $pages += [ordered]@{
        id           = $id
        title        = $name
        body         = $body
        lastModified = $iso
        attachments  = $attachments
    }
}

Write-ExportProgress "status=書き出し結果を保存しています"
if (-not (Test-Path -LiteralPath $outDir)) { New-Item -ItemType Directory -Force -Path $outDir | Out-Null }
[array]$pages = @($pages)
$jsonText = ConvertTo-PageJson $pages
[System.IO.File]::WriteAllText($OutputJson, $jsonText, (New-Object System.Text.UTF8Encoding $false))
$jsonBytes = (Get-Item -LiteralPath $OutputJson).Length
Write-ExportProgress ("diag=outputJson=" + $OutputJson)
Write-ExportProgress ("diag=jsonBytes=" + $jsonBytes)
Write-ExportProgress ("exported=" + $pages.Count)
