﻿param(
    [Parameter(Mandatory = $true)][int]$WaitPid,
    [Parameter(Mandatory = $true)][string]$StagingDir,
    [Parameter(Mandatory = $true)][string]$InstallDir
)

$ErrorActionPreference = "Stop"
$log = Join-Path $env:TEMP "saigai-apply-update.log"
function Write-Log($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg"
    Add-Content -LiteralPath $log -Value $line -Encoding UTF8
}

Write-Log "start WaitPid=$WaitPid Staging=$StagingDir Install=$InstallDir"
if ($WaitPid -gt 0) {
    try { Wait-Process -Id $WaitPid -ErrorAction SilentlyContinue } catch { }
}
Start-Sleep -Seconds 2

function Copy-IfExists($from, $to) {
    if (Test-Path -LiteralPath $from) {
        Copy-Item -LiteralPath $from -Destination $to -Recurse -Force
    }
}

$appSrc = Join-Path $StagingDir "app"
$rtSrc = Join-Path $StagingDir "runtime"
if (Test-Path $appSrc) {
    $destApp = Join-Path $InstallDir "app"
    if (Test-Path -LiteralPath $destApp) {
        Get-ChildItem -LiteralPath $destApp -Filter "saigai-viewer-*.jar" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
    }
    robocopy $appSrc $destApp /E /NFL /NDL /NJH /NJS /nc /ns /np | Out-Null
    $script:LASTEXITCODE = 0
}
$destJava = Join-Path $InstallDir "runtime\bin\java.exe"
if (Test-Path $rtSrc) {
    if (Test-Path -LiteralPath $destJava) {
        Write-Log "skip runtime (already installed)"
    } else {
        robocopy $rtSrc (Join-Path $InstallDir "runtime") /E /NFL /NDL /NJH /NJS /nc /ns /np | Out-Null
        $script:LASTEXITCODE = 0
    }
}
Copy-IfExists (Join-Path $StagingDir "SaigaiViewer.exe") (Join-Path $InstallDir "SaigaiViewer.exe")
Copy-IfExists (Join-Path $StagingDir "version.txt") (Join-Path $InstallDir "version.txt")
Copy-IfExists (Join-Path $StagingDir "build-info.properties") (Join-Path $InstallDir "build-info.properties")
$androidSrc = Join-Path $StagingDir "android"
if (Test-Path -LiteralPath $androidSrc) {
    robocopy $androidSrc (Join-Path $InstallDir "android") /E /NFL /NDL /NJH /NJS /nc /ns /np | Out-Null
    $script:LASTEXITCODE = 0
}
$scriptsSrc = Join-Path $StagingDir "scripts"
if (Test-Path -LiteralPath $scriptsSrc) {
    robocopy $scriptsSrc (Join-Path $InstallDir "scripts") /E /NFL /NDL /NJH /NJS /nc /ns /np | Out-Null
    $script:LASTEXITCODE = 0
}

$exe = Join-Path $InstallDir "SaigaiViewer.exe"
if (Test-Path $exe) {
    $started = $false
    for ($i = 1; $i -le 8; $i++) {
        try {
            Start-Process -FilePath $exe
            $started = $true
            Write-Log "restarted exe attempt=$i"
            break
        } catch {
            Write-Log "restart failed attempt=$i $($_.Exception.Message)"
            Start-Sleep -Seconds 1
        }
    }
    if (-not $started) {
        Write-Log "failed to restart $exe"
    }
} else {
    Write-Log "exe missing: $exe"
}
Write-Log "done"
